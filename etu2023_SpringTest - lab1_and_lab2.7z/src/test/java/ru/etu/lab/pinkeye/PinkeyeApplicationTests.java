package ru.etu.lab.pinkeye;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PinkeyeApplicationTests {

	@Test
	void contextLoads() {
	}

}
